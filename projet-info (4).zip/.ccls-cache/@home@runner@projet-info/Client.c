#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "files.h"


int Client(){
  int choixclient;
  printf("Vous êtes en mode client.\n");
    printf("Que voulez-vous faire :\n");
    printf("\n1.Se connecter\n2.Nouveau compte\n3.Supprimer un compte\n4.Quitter\n");
    scanf("%d",&choixclient);
		do{
			switch(choixclient){
				case(1):
					Connexion();
					break;
				case(2):
				  Newclient();
          break;  
				case(3):
					Supprimerclient();
          break;
        case(4):
          Menu();
				default:
					printf("Entrez un des choix possible\n");
					break;
			}
		}while(choixclient>4 || choixclient<=0);
return 0;
}
