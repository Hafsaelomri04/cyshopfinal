#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "files.h"

int Gerant(){
  int motdepasse, checkmotdepasse, tentatives, choixgerant;
  checkmotdepasse = 1234;
  tentatives = 3;
  while (tentatives > 0) {
  printf("Entrez le mot de passe du gérant :\n");
  scanf("%d",&motdepasse);
	if(motdepasse==checkmotdepasse){
    printf("Vous êtes en mode gérant.\n");
    printf("Que voulez-vous faire :\n");
    printf("\n1.Afficher le stock de voitures\n2.Afficher les voitures en rupture de stock\n3.Ajouter une voiture\n4.Supprimer une voiture\n5.Afficher les clients\n6.Supprimer un client\n7.Quitter\n");
    scanf("%d",&choixgerant);
		do{
			switch(choixgerant){
				case(1):
					Listevoitures();
					Gerant();
					break;
				//case(2):
					//Listerupture();
          //Gerant();
					//break;
        case(3):
          Ajouter();
          Gerant();
        case(4):
          Supprimer();
          Gerant();
        case(5):
          Listeclients();
          Gerant();
        //case(6):
          //Supprimerclient();
          //Gerant();
				case(7):
					Menu();
				default:
					printf("Entrez un des choix possible\n");
					break;
			}
		}while(choixgerant>7 || choixgerant<=0);
		
	}
  else{
    tentatives--;
    printf("Le mot de passe est incorrect !! \n");
  }
  }
  if(tentatives==0){
    printf("Tentatives épuisées. Accès refusé.\n");
    Menu();
    }
  return 0;
  }

