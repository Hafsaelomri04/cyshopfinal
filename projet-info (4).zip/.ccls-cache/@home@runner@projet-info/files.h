#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int Connexionreussie();
int Connexion();
int Newclient();
int Client();
int Gerant();
int Menu();