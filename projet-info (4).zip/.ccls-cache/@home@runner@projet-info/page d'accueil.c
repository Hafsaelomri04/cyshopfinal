int main(){
  int compte;
  printf("Avez-vous un compte ? (repondre 1 pour oui ou 2 pour non)");
  scanf("%d", &compte);
  if(compte==1){
    
  }
  else{
    //fopen creer un compte
  }
}