#include <stdio.h>

//Structure des tailles des produits
typedef struct {
char G;
char S;
char C;
} Classe;

//Structure de stockage des produits
typedef struct {
char nomproduita[50];
char referencea[50];
int quantiteenstock;
float prix;
struct Classe;
} Produit;

//Structure de recherche
typedef struct{
char nomproduitb[50];
char referenceb[50];
} Recherche;

//Comparaison des noms des produits
  int rechercheparnom (char nomproduita[50],char nomproduitb[50]){
    if(strcmp(nomproduita,nomproduitb)==0){
      return 1;
    }
    else{
      return 0;
    }
  };

//Comparaison des references des produits
  int rechercheparreference (char referencea[50],char referenceb[50]){
    if(strcmp(referencea,referenceb)==0){
      return 1;
    }
    else{
      return 0;
    }
  };

//Structure de stockage des informations des client
typedef struct {
char nomclient[50];
char prenomclient[50];

}


//pour acceder a un fichier
//FILE* fopen( const char* nomFichier, const char* modeAcces ) : fichier = fopen("test.txt", "r+");